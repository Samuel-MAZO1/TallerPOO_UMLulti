package com.taller.seccion1;
import java.util.Scanner;
public class Ejercicio6 {
	public static void main(String[]args) {
		
	}

	
}
