package com.taller.seccion1;
import java.util.Scanner;
public class Ejercicio5 {
    
	public static void main(String[]args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Añade un número: ");
	    double n1 = sc.nextInt();
	    System.out.print("Añade otro número: ");
	    double n2 = sc.nextInt();
	    if (n2 < 5 && n1> 3) { //Si se cumplen estas dos condiciones entrará a este bloque de código.
	    	System.out.println("Maestro del programa, bienvenido");
	    }
	    if (n2 > 5 || n1 < 3) {
	    	System.out.println("Maestro del programa, bienvenido");
	    }
	    if (!(n2 == 5) || n1 != 3) {
	    	System.out.println("Maestro del programa, bienvenido");
	    }
	    sc.close(); //Cierro el Scanner
	}
}