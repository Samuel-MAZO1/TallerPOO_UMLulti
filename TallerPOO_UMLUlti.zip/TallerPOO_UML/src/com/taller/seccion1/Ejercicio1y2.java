package com.taller.seccion1;
public class Ejercicio1y2 {
     public static void main (String[] args) {
    	 double d = 10.2;
    	 int i = 15;
    	 char c = "a";
    	 String saludo = "hola";
    	 boolean esUtil = true;
    	 System.out.println(d);
    	 System.out.println(i);
    	 System.out.println(c);
    	 System.out.println(saludo);
    	 System.out.println(esUtil);
    	 
     }
}
