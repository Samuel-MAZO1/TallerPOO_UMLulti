package com.taller.seccion1;

public class Ejercicio7 {

	public static void main(String[]args) {
		String n = "123";
		int c = Integer.parseInt(n);
		double d = Double.parseDouble(n);
		String n1 = Integer.toString(c);
		String n2 = Double.toString(d);
		System.out.println(n1);
		System.out.println(n2);
	}
}
