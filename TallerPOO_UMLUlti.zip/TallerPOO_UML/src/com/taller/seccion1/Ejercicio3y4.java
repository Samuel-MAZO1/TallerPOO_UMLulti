package com.taller.seccion1;

public class Ejercicio3y4 {
    
	public static void main(String[]args) {
		double x1 = 1.1;
		double x2 = 2.2;
		
		System.out.println("Operaciones aritmeticas: ");
		System.out.println("");
	    System.out.println("Suma: " + (x1 + x2));
	    System.out.println("Resta: " + (x2 - x1));
	    System.out.println("División: " + (x1 / x2));
	    System.out.println("Multiplicacion: " + (x1 * x2));
	    System.out.println("Módulo: " + (x1 % x2));
	    System.out.println("");
	    System.out.println("");
	    
	}
}
