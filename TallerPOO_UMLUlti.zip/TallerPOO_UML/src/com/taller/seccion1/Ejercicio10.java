package com.taller.seccion1;

public class Ejercicio10 {

	public static void main(String[]args) {
		double n1 = 25;
		double h1 = 15;
		double n2 = Math.sqrt(n1);
		System.out.println(n2);
		double h2 = Math.pow(h1, 10);
		System.out.println(h2);
	}
}
