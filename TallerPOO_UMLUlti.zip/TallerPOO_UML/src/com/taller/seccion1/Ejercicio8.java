package com.taller.seccion1;

public class Ejercicio8 {
	public static void main(String[]args) {
		String n = "1a";
		try {
			double n1 = Double.parseDouble(n);
			System.out.println(n1);
		}
		catch(NumberFormatException e) {
			System.err.println("Que falla mi hermano");
		}
		System.out.println("CoNtInUe");
	}

}
