package com.taller.seccion1;

public class Ejercicio11 {

	public static void main(String[]args) {
		double h = Math.random();
		System.out.println(h);
	}
}
