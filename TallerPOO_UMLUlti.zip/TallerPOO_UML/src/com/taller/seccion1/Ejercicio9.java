package com.taller.seccion1;

public class Ejercicio9 {

	public static void main(String[]args) {
		final double n = 5.5;
		System.out.println(n);
	}
}
