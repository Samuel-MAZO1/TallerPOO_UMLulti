package com.taller.seccion5;
import java.util.Scanner;
public class Ejercicio6 {
	int a;
	public static void main(String[]args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Ingresa bro:");
	int a = sc.nextInt();
	sc.close();
	}
}
