package com.taller.seccion5;

public class Ejercicio5 {
	private int a = 5;
	public int b = 0;
	protected int x = 22;
	int ab = 12;
}
