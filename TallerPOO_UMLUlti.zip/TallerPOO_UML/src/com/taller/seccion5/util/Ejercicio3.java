package com.taller.seccion5.util;

public class Ejercicio3 {
    
    private double resultado;

    public Ejercicio3() {
        this.resultado = 0;
    }

    public double sumar(double a, double b) {
        resultado = a + b;
        return resultado;
    }

    public double restar(double a, double b) {
        resultado = a - b;
        return resultado;
    }
    
    public double multiplicar(double a, double b) {
        resultado = a * b;
        return resultado;
    }

    public double dividir(double a, double b) {
        if (b == 0) {
            System.out.println("Error: División por cero no permitida.");
            return Double.NaN;
        }
        resultado = a / b;
        return resultado;
    }

    public double obtenerResultado() {
        return resultado;
    }
}
