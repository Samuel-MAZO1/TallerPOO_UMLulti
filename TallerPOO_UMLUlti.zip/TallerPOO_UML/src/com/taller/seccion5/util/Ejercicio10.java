package com.taller.seccion5.util;

public class Ejercicio10 {
	final double PI = 3.141592653589793;

    public double sumar(double a, double b) {
        return a + b;
    }

    public double restar(double a, double b) {
        return a - b;
    }

    public double multiplicar(double a, double b) {
        return a * b;
    }
 
    public double dividir(double a, double b) {
        if (b == 0) {
            System.out.println("Error: División por cero no permitida.");
            return Double.NaN;
        }
        return a / b;
    }
}

