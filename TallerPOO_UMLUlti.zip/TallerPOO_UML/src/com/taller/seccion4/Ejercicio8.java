package com.taller.seccion4;

public class Ejercicio8 {
    private String nombre;
    private int edad;

    public Ejercicio8(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

 
    public String toString() {
        return "Persona: " + nombre + ", Edad: " + edad;
    }

    public static void main(String[] args) {
        Ejercicio8 persona1 = new Ejercicio8("Ana", 28);
        System.out.println(persona1);
    }
}
