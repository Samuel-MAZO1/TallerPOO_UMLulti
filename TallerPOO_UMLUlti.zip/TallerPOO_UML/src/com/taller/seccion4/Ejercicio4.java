package com.taller.seccion4;

public class Ejercicio4 {

	private String nombre;
    private int edad;

    public Ejercicio4() {
        this.nombre = "Desconocido";
        this.edad = 0;
    }

    public Ejercicio4(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        if (edad >= 0) {
            this.edad = edad;
        } else {
            System.out.println("Error: La edad no puede ser negativa.");
        }
    }
    public void presentarse() {
        System.out.println("¡Hola! Mi nombre es " + nombre + " y tengo " + edad + " años.");
    }
}