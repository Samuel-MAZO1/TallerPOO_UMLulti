package com.taller.seccion4;

public class MainPersona {
    public static void main(String[] args) {
    	
        Ejercicio4 persona1 = new Ejercicio4();
        persona1.presentarse();

        Ejercicio4 persona2 = new Ejercicio4("Carlos", 30);
        persona2.presentarse();

        Ejercicio4 persona3 = new Ejercicio4("Ana", -5);
        persona3.presentarse();
    }
}