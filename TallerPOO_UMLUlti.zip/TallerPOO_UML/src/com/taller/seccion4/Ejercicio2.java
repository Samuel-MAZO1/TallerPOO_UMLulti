package com.taller.seccion4;

public class Ejercicio2 {
	private String nombre;
    private int edad;

    public Ejercicio2() {
        this.nombre = "Desconocido";
        this.edad = 0;
    }

    public Ejercicio2(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

}
