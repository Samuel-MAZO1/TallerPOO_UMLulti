package com.taller.seccion3;

public class Ejercicio1 {
	public static void main(String[] args) {
        int[] numeros = new int[5];
	}
	

}
