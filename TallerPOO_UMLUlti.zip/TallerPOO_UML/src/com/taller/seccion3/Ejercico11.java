package com.taller.seccion3;

public class Ejercico11 {
	public static void main(String[] args) {
        List<String> lista = new ArrayList<>(Arrays.asList("R", "A", "V", "A", "A"));

        Iterator<String> iterador = lista.iterator();

        while (iterador.hasNext()) {
            String color = iterador.next();
            if ("Azul".equals(color)) {
                iterador.remove();
            }
        }

        System.out.println("eliminar 'A': " + lista);
    }

}
