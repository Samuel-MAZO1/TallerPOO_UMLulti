package com.taller.seccion3;

public class Ejercicio3 {
	public static void main(String[] args) {
        String[] frutas = {"Manzana", "Banana", "Cereza"};
        
        for (int i = 0; i < frutas.length; i++) {
            System.out.println("Índice " + i + ": " + frutas[i]);
        }
    }

}
