package com.taller.seccion3;

public class Ejercicio2 {
	public static void main(String[] args) {
        String[] frutas = {"Manzana", "Banano", "Cereza"};

        for (String fruta : frutas) {
            System.out.println(fruta);
        }
    }

}
