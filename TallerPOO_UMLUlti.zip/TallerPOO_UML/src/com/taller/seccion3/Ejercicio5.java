package com.taller.seccion3;

public class Ejercicio5 {
	public static void main(String[] args) {
        Integer[] arreglo = {10, 20, 30, 40, 50};
        ArrayList<Integer> lista = new ArrayList<>(Arrays.asList(arreglo));
        lista.add(60);
        System.out.println(lista);
    }

}
