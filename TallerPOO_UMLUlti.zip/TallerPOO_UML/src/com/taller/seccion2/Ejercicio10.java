package com.taller.seccion2;

public class Ejercicio10 {

}
