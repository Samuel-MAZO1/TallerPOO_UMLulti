package com.taller.seccion2;
public class Ejercicio4 {
	public static void main(String[]args) {
		int factorial = 0;
		for (int i = 1; i < 20; i++) {
			while (i == 1) {
			factorial = i * (i-1);
			
			}
			System.out.println("Número: " + i);
			System.out.println("factorial: " + factorial);
			
		}
	}

}
