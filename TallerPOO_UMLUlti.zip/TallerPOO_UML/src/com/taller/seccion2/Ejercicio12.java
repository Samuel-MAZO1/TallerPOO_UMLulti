package com.taller.seccion2;
import java.util.Collections;
public class Ejercicio12 {
	 public static void main(String[] args) {
	        int[] numeros = new int[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
	        
	        Collections.sort(numeros);

	        
	        for (int num : numeros) {
	            if (num % 2 == 0) {
	                System.out.println(num);
	            }
	        }
	    }

}
