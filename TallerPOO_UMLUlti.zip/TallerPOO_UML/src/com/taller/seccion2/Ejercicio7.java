package com.taller.seccion2;

public class Ejercicio7 {
	public static void main(String[]args) {
		for (int i = 1; i < 20; i++) {
			if (i == 2) {
				System.out.println("El programa empezó");
				continue;
				}
			if (i == 5) {
				System.out.println("Se rompió en el número: " + i);
			break;
			}
		}
	}
}
