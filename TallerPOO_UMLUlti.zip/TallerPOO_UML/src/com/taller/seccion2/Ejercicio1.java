package com.taller.seccion2;
import java.util.Scanner;
public class Ejercicio1 {
	public static void main(String[]args) {
		Scanner sc = new Scanner(System.in);
		double n1 = sc.nextDouble();
		double n2 = sc.nextDouble();
		if (n1 > n2) {
			System.out.println("Fiera");
		}
		else {
			System.out.println("Bot");
		}
	}

}
