package com.taller.seccion2;
import java.util.Scanner;
public class Ejercicio6 {
	public static void main(String[]args) {
		Scanner sc = new Scanner(System.in);
		String password;
		
		do {
			System.out.print("Introduce la contraseña: ");
			password = sc.nextLine();
		}
		while (!password.equals("125abc")); {
			System.out.println("Contraseña correcta");
		}sc.close();
	}

}
