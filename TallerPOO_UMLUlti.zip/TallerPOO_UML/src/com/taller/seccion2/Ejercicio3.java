package com.taller.seccion2;
import java.util.Scanner;
public class Ejercicio3 {
	public static void main(String[]args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Menú de opciones: ");
		System.out.println("");
		System.out.println("1. Ver el número 1");
		System.out.println("2. Ver el número 2");
		System.out.println("3. ver el número 3");
		System.out.print("Ingrese una opción: ");
		int opcion = sc.nextInt();
		switch (opcion) {
		case 1:
			System.out.println(1);
			break;
			
		case 2:
			System.out.println(2);
			break;
			
		case 3:
			System.out.println(3);
			break;
		}sc.close();
	}
}
