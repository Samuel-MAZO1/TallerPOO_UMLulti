package com.taller.seccion2;
import java.util.Scanner;
public class Ejercicio5 {
	public static void main(String[]args) {
		Scanner sc = new Scanner(System.in);
		int x = sc.nextInt();
		int suma = 0;
		while (x != 0){
			suma += x;
			System.out.println(suma);
		}
		System.out.println("Has ingresado el cero");
		sc.close();
	}
   
}
