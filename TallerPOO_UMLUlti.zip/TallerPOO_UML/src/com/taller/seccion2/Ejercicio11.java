package com.taller.seccion2;

public class Ejercicio11 {
	 public static void main(String[] args) {
	        int[] numeros = new int[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
	        for (int num : numeros) {
	            if (num % 2 == 0) {
	                System.out.println(num);
	            }
	        }
	    }

}
