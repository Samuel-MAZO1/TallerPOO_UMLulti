package com.taller.seccion2;
import java.util.Scanner;
public class Ejercicio2 {
	public static void main(String[]args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Ingrese su edad: ");
		int age = sc.nextInt();
		
		if (age <= 28 && age > 0) {
			if (age > 0 && age <= 14) {
				System.out.println("Usted es un niño/a");
			} else {
				System.out.println("Usted es un adolescente");			
			}			
		}
		if (age > 28 && age <= 100) {
			if (age <= 60 && age >28) {
				System.out.println("Usted es un adulto");
			}
			else {
				System.out.println("Usted es un anciano");
		    } 
		
		}sc.close();
		
	}
}
