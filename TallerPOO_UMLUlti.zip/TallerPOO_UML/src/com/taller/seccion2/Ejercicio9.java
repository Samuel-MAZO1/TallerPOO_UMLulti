package com.taller.seccion2;

public class Ejercicio9 {
	public static void main(String[] args) {
        String[] nombres = {"Juan", "Samuel", "Maldonado", "Brayan"};
        
        for (String nombre : nombres) {
            System.out.println(nombre);
        }
    }

}
